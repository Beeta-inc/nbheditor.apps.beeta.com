// JS from previous step (same as before)
